package com.problem_3;

class Flute extends Instrument {
	public void Play()

	{
		System.out.println("Flute is playing  toot toot toot toot");
	}
}

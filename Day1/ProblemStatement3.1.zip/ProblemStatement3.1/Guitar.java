package com.problem_3;

class Guitar extends Instrument {
	public void Play() {
		System.out.println("Guitar is playing  tin  tin  tin ");
	}
}

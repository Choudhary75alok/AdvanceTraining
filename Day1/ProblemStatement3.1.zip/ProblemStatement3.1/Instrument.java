package com.problem_3;

public abstract class Instrument {
	public abstract void Play();
}

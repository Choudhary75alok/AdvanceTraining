package com.problem_3;

class Piano extends Instrument {
	public void Play() {
		System.out.println("Piano is playing  tan tan tan tan");
	}
}
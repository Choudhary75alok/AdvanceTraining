package com.problem_1;

class BookDetail {
	 String bookName;
	 double bookPrice;

	BookDetail(String title, double price) {

		bookName = title;
		bookPrice = price;
	}

	String getBookName() {
		return bookName;
	}
	
	void setBookName(String s) {
		bookName = s;
	}

	double getBookPrice() {
		return bookPrice;
	}

	void setBookPrice(double p) {
		bookPrice = p;
	}


	

}

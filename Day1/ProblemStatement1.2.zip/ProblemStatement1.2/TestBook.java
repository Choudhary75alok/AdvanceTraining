package com.problem_1;

import java.awt.print.Book;
import java.util.Scanner;

public class TestBook {

	
		static Scanner sc=new Scanner(System.in);
		public static void Createbooks(BookDetail[] b) {
			for (int i = 0; i< b.length;i++) {
				System.out.println("Enter Book"+(i+1)+" detail:");
				System.out.println("Book name:");
				sc.nextLine();
				String t = sc.nextLine();
				System.out.println("Price: ");
				double p=sc.nextDouble();
				b[i]= new BookDetail(t,p);
			}
		}
		
		public static void showBook(BookDetail[] b) {
			System.out.println("Book name\t  Book Price");
			System.out.println("--------------------------");
			String r="RS";
			for(int i=0;i<b.length;i++) {
				System.out.printf("%-20s%6s",b[i].getBookName(),r);
				System.out.println(b[i].getBookPrice());
			}
			
		}
		
		public static void main(String[] args) {
			System.out.println("Number of books: ");
			int n=sc.nextInt();
			BookDetail[] b=new BookDetail[n];
			Createbooks(b);
			showBook(b);
		}
	}


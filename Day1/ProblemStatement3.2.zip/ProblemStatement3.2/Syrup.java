package com.problem_3;

public class Syrup implements MedicineInfo {

	@Override
	public void displayLable() {
		// TODO Auto-generated method stub
		System.out.println("Consumption as directed by the physician");
	}


}

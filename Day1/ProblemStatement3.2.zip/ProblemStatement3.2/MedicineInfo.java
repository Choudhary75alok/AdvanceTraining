package com.problem_3;

public interface MedicineInfo {
	String CompanyName="Alok Pharma";
	String CompanyAddress="GKP";
	void displayLable();
		
	}
	



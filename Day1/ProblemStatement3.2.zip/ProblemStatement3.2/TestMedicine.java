package com.problem_3;

public class TestMedicine {
	public static void main(String[] args) {
		MedicineInfo m[] = new MedicineInfo[10];
		double i = Math.random() * 4;
		int j = (int) i;
		System.out.println(j);
		switch (j) {
		case 1:
			m[0] = new Tablet();
			m[0].displayLable();

			break;

		case 2:
			m[2] = new Syrup();

			m[2].displayLable();

			break;
		case 3:
			m[4] = new Ointment();

			m[4].displayLable();

			break;

		default:
			System.out.println("Invalid Choice");
		}
	}
}

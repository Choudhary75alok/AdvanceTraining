package com.problem_3;

public class Tablet implements MedicineInfo {

	@Override
	public void displayLable() {
		// TODO Auto-generated method stub
		System.out.println("store in a cool dry place");

	}

}

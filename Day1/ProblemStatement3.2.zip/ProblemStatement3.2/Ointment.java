package com.problem_3;

public class Ointment implements MedicineInfo {
	
	@Override
	public void displayLable() {
		// TODO Auto-generated method stub
		System.out.println("For external use only");
	}

}

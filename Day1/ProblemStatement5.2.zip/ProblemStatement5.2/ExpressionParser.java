package com.problem_5;

public class ExpressionParser {

	public static void main(String[] args) {

		String text = "23 + 45  - (343  /  12)";
		String[] w = text.split("\\\r");
		
		for(String w1:w) {
			System.out.println(w1);
			System.out.println(" ");
		}
	}
}

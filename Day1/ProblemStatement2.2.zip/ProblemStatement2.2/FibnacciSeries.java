package com.problem_2;

public class FibnacciSeries {

public static void main(String[] args) {
	
	//without using recursion
	
	int n1=1,n2=3,n3,i,count=13;
	System.out.print(n1+" "+n2);
	for(i=2;i<count;i++) {
		n3=n1+n2;
		n1=n2;
		n2=n3;
		System.out.print(" "+n3);
		
	}
	
		
	
	
}
	
	
}
